/**
 * \file Findcppcheck.cpp
 * \brief Dummy C++ source file used by CMake module Findcppcheck.cmake
 *
 * \author
 * Ryan Pavlik, 2009-2010
 * <rpavlik@iastate.edu>
 * http://academic.cleardefinition.com/
 *
 */



int main(int argc, char* argv[]) {
	return 0;
}
